CREATE TABLE records(
 id TEXT PRIMARY KEY, district TEXT NOT NULL, ac_number TEXT NOT NULL,
 assembly_name TEXT NOT NULL, part_no TEXT NOT NULL, part_name TEXT NOT NULL,
 blo_name TEXT NOT NULL, designation TEXT NOT NULL DEFAULT '',
 mobile_number TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL
);
CREATE INDEX ix_records_district ON records(district);
CREATE INDEX ix_records_ac ON records(ac_number);
CREATE INDEX ix_records_part ON records(part_no);
CREATE INDEX ix_records_blo_name ON records(blo_name);
