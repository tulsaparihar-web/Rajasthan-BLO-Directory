# Rajasthan BLO Directory — starter project
Android Studio project (Kotlin, Jetpack Compose, Material 3, Room) and FastAPI backend with SQLite database and embedded source workbook data.

## Dataset
Embedded CSV has 61,362 rows and eight citizen-facing fields: District, AC Number, Assembly Name, Part No, Part Name, BLO Name, Designation, MobileNumber. `BLO Name` maps from source `User Name`; `MobileNumber` maps from source `User Id` as requested. Confirm the User Id values are genuine phone numbers before release. Google Maps/directions functionality has been removed because verified coordinates are not available.

The columns Department Name, Joining Date, Last Login Time and Last Logout Time are removed. User Id is renamed, not discarded. EPIC Number is excluded.

## Android
Open `android/` in Android Studio with JDK 17. Sync Gradle and run. Build a debug APK using Build > Build APK(s).

## Backend
In `backend/`, create a virtual environment, install `requirements.txt`, copy `.env.example` to `.env`, set a long random `ADMIN_API_KEY`, and run `uvicorn main:app --host 0.0.0.0 --port 8000`.

Endpoints: `/health`, `/api/v1/directory`, `/api/v1/sync`, protected admin POST/PUT. The shared API key is a development baseline; production requires HTTPS, government SSO/roles, rate limiting, audit logs, backups and security review.

This is source code, not a compiled release APK. A signed release requires the department-owned signing key, production API configuration, contact-data validation and device testing.
