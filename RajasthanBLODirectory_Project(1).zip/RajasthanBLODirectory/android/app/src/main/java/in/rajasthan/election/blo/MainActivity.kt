package in.rajasthan.election.blo
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{DirectoryApp(BloDatabase.get(this))}}}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DirectoryApp(db:BloDatabase){
 val ctx= LocalContext.current;val scope= rememberCoroutineScope()
 var hi by remember{mutableStateOf(false)};var query by remember{mutableStateOf("")};var district by remember{mutableStateOf("")}
 var districts by remember{mutableStateOf(listOf<String>())};var rows by remember{mutableStateOf(listOf<BloRecord>())};var total by remember{mutableIntStateOf(0)}
 LaunchedEffect(Unit){seedFromAssets(ctx,db);districts=db.dao().districts();total=db.dao().count();rows=db.dao().search("","","")}
 MaterialTheme(colorScheme=lightColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF17365D),secondary=androidx.compose.ui.graphics.Color(0xFFFF9933))){
 Scaffold(topBar={TopAppBar(title={Column{Text(if(hi)"राजस्थान BLO निर्देशिका" else "Rajasthan BLO Directory",fontWeight=FontWeight.Bold);Text(if(hi)"निर्वाचन विभाग, राजस्थान" else "Election Department, Rajasthan",style=MaterialTheme.typography.labelSmall)}},actions={TextButton(onClick={hi=!hi}){Text(if(hi)"English" else "हिन्दी")}})}){pad->
 Column(Modifier.padding(pad).padding(14.dp).fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)){
 Text(if(hi)"अपना BLO और मतदान केंद्र खोजें" else "Find your BLO and polling station",style=MaterialTheme.typography.titleMedium)
 OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text(if(hi)"नाम, भाग संख्या या केंद्र" else "Name, part number or polling station")})
 var expanded by remember{mutableStateOf(false)}
 ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}){
 OutlinedTextField(district.ifBlank{if(hi)"सभी जिले" else "All districts"},{},readOnly=true,modifier=Modifier.menuAnchor().fillMaxWidth(),label={Text(if(hi)"जिला" else "District")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
 ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
 DropdownMenuItem(text={Text(if(hi)"सभी जिले" else "All districts")},onClick={district="";expanded=false})
 districts.forEach{d->DropdownMenuItem(text={Text(d)},onClick={district=d;expanded=false})}
 }}
 Button(onClick={ scope.launch { rows=db.dao().search(query.trim(),district,"") } },modifier=Modifier.fillMaxWidth()){Text(if(hi)"खोजें" else "Search")}
 Text(if(hi)"ऑफ़लाइन उपलब्ध • $total रिकॉर्ड" else "Offline data available • $total records",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
 if(rows.isEmpty())Text(if(hi)"कोई रिकॉर्ड नहीं मिला।" else "No records found.")
 LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(rows,key={it.id}){r->ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
 Text(r.bloName.ifBlank{if(hi)"नाम उपलब्ध नहीं" else "Name unavailable"},style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
 Text(r.designation,style=MaterialTheme.typography.bodySmall)
 Text("${r.district} | ${r.acNumber} - ${r.assemblyName}")
 Text("${if(hi)"भाग संख्या" else "Part No."}: ${r.partNo} • ${r.partName}")
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
  if(r.mobileNumber.isNotBlank()) {
 Button(onClick={ctx.startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:${Uri.encode(r.mobileNumber)}")))}) { Text(if(hi)"कॉल करें" else "Call") }
 } else {
 OutlinedButton(onClick={},enabled=false){Text(if(hi)"फोन उपलब्ध नहीं" else "Phone unavailable")}
 }
 }
 }}}}
 }}
}
