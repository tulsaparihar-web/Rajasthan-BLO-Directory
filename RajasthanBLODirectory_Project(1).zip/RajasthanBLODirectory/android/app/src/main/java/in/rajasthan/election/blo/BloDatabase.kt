package in.rajasthan.election.blo
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Entity(tableName="blo_records", indices=[Index("district"),Index("assemblyName"),Index("partNo"),Index("bloName")])
data class BloRecord(
 @PrimaryKey val id:String,
 val district:String,
 val acNumber:String,
 val assemblyName:String,
 val partNo:String,
 val partName:String,
 val bloName:String,
 val designation:String,
 val mobileNumber:String = "",
 val updatedAt:Long = 0L
)

@Dao interface BloDao {
 @Query("SELECT * FROM blo_records WHERE (:q='' OR lower(bloName) LIKE '%'||lower(:q)||'%' OR lower(partName) LIKE '%'||lower(:q)||'%' OR partNo LIKE '%'||:q||'%' OR lower(assemblyName) LIKE '%'||lower(:q)||'%') AND (:district='' OR lower(district)=lower(:district)) AND (:ac='' OR acNumber=:ac) ORDER BY district,assemblyName,partNo LIMIT 300")
 suspend fun search(q:String,district:String,ac:String):List<BloRecord>
 @Query("SELECT DISTINCT district FROM blo_records WHERE district!='' ORDER BY district") suspend fun districts():List<String>
 @Query("SELECT COUNT(*) FROM blo_records") suspend fun count():Int
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(rows:List<BloRecord>)
}
@Database(entities=[BloRecord::class],version=2,exportSchema=true)
abstract class BloDatabase:RoomDatabase(){
 abstract fun dao():BloDao
 companion object { @Volatile private var instance:BloDatabase?=null
  fun get(c:Context):BloDatabase=instance?: synchronized(this){instance?:Room.databaseBuilder(c.applicationContext,BloDatabase::class.java,"rajasthan_blo.db").fallbackToDestructiveMigration().build().also{instance=it}}
 }
}
suspend fun seedFromAssets(c:Context,db:BloDatabase)=withContext(Dispatchers.IO){
 if(db.dao().count()>0)return@withContext
 c.assets.open("blo_directory.csv").bufferedReader(Charsets.UTF_8).useLines{lines->
  val it=lines.iterator();if(it.hasNext())it.next()
  val batch=mutableListOf<BloRecord>()
  while(it.hasNext()){
   val f=parseCsv(it.next())
   if(f.size>=8){
    val id=listOf(f[0],f[1],f[3],f[5],f[7]).joinToString("|").lowercase()
    batch.add(BloRecord(id,f[0],f[1],f[2],f[3],f[4],f[5],f[6],f[7]))
    if(batch.size>=500){db.dao().upsertAll(batch.toList());batch.clear()}
   }
  }
  if(batch.isNotEmpty())db.dao().upsertAll(batch)
 }
}
fun parseCsv(s:String):List<String>{val a=mutableListOf<String>();val b=StringBuilder();var q=false;var i=0
 while(i<s.length){val c=s[i];if(c=='"'){if(q&&i+1<s.length&&s[i+1]=='"'){b.append('"');i++}else q=!q}else if(c==','&&!q){a.add(b.toString());b.clear()}else b.append(c);i++};a.add(b.toString());return a}
