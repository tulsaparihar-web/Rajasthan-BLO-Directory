# Data dictionary
- `district`, `ac_number`, `assembly_name`, `part_no`, `part_name`: source workbook location and station fields.
- `blo_name`: renamed from source `User Name`.
- `mobile_number`: renamed from source `User Id` as requested; displayed as the contact number and used by the Call action. Please verify these values are valid dialable mobile numbers before public deployment.
- `designation`: source workbook designation.
- Removed columns: Department Name, Joining Date, Last Login Time, Last Logout Time.
- Maps/directions functionality is removed because verified coordinates are unavailable.
- EPIC Number is not included in the citizen-facing dataset.
