# Production checklist
- Confirm lawful authority and currency of source records.
- Validate district/AC/part mappings against official polling-station master.
- Add verified public phone numbers and official polling-station coordinates.
- Replace shared development key with government SSO/OIDC, roles and audit trail.
- Configure HTTPS, secrets management, rate limits, backups and monitoring.
- Implement delta sync, version/ETag and clear stale-data policy.
- Test Hindi translations, accessibility, low-end devices and offline behavior.
- Configure production API URL, disable cleartext traffic, security-review dependencies.
- Sign release APK with department-owned key and document key custody.
