import csv, os, secrets, sqlite3, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Header, HTTPException, Query
from pydantic import BaseModel, Field
from dotenv import load_dotenv
load_dotenv()
BASE=Path(__file__).resolve().parent
DB=BASE/"directory.sqlite3"
CSV_PATH=BASE/os.getenv("DIRECTORY_CSV","blo_directory.csv")
ADMIN_KEY=os.getenv("ADMIN_API_KEY","")
app=FastAPI(title="Rajasthan BLO Directory API",version="1.0.2")
def connect():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def init_db():
 with connect() as c:
  c.execute("CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,district TEXT NOT NULL,ac_number TEXT NOT NULL,assembly_name TEXT NOT NULL,part_no TEXT NOT NULL,part_name TEXT NOT NULL,blo_name TEXT NOT NULL,designation TEXT NOT NULL,mobile_number TEXT NOT NULL DEFAULT '',updated_at INTEGER NOT NULL)")
  c.execute("CREATE INDEX IF NOT EXISTS ix_district ON records(district)")
  if c.execute("SELECT COUNT(*) FROM records").fetchone()[0]==0 and CSV_PATH.exists():
   with CSV_PATH.open(encoding="utf-8-sig",newline="") as f:
    for r in csv.DictReader(f):
     key="|".join([r.get("District",""),r.get("AC Number",""),r.get("Part No",""),r.get("BLO Name",""),r.get("MobileNumber","")]).lower()
     c.execute("INSERT OR IGNORE INTO records(id,district,ac_number,assembly_name,part_no,part_name,blo_name,designation,mobile_number,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(key,r.get("District",""),r.get("AC Number",""),r.get("Assembly Name",""),r.get("Part No",""),r.get("Part Name",""),r.get("BLO Name",""),r.get("Designation",""),r.get("MobileNumber",""),int(time.time())))
  c.commit()
@app.on_event("startup")
def startup(): init_db()
class RecordIn(BaseModel):
 id:str=Field(min_length=1,max_length=300)
 district:str;ac_number:str;assembly_name:str;part_no:str;part_name:str;blo_name:str
 designation:str="";mobile_number:str=""
def guard(key):
 if not ADMIN_KEY: raise HTTPException(503,"Admin API disabled: configure ADMIN_API_KEY.")
 if not key or not secrets.compare_digest(key,ADMIN_KEY): raise HTTPException(401,"Invalid admin credentials.")
def public(r): return dict(r)
@app.get("/health")
def health():
 with connect() as c:n=c.execute("SELECT COUNT(*) FROM records").fetchone()[0]
 return {"status":"ok","records":n,"server_time":int(time.time())}
@app.get("/api/v1/directory")
def directory(query:str="",district:str="",ac_number:str="",limit:int=Query(50,ge=1,le=300),offset:int=Query(0,ge=0)):
 sql="SELECT id,district,ac_number,assembly_name,part_no,part_name,blo_name,designation,mobile_number,updated_at FROM records WHERE 1=1";a=[]
 if query: sql+=" AND (blo_name LIKE ? OR part_name LIKE ? OR part_no LIKE ? OR assembly_name LIKE ? OR mobile_number LIKE ?)";a += [f"%{query}%"]*5
 if district: sql+=" AND lower(district)=lower(?)";a.append(district)
 if ac_number: sql+=" AND ac_number=?";a.append(ac_number)
 with connect() as c:
  total=c.execute("SELECT COUNT(*) FROM records").fetchone()[0]
  rows=c.execute(sql+" ORDER BY district,assembly_name,part_no LIMIT ? OFFSET ?",a+[limit,offset]).fetchall()
 return {"version":1,"total_records":total,"limit":limit,"offset":offset,"items":[public(r) for r in rows]}
@app.get("/api/v1/sync")
def sync(since_version:int=0,limit:int=Query(300,ge=1,le=1000),offset:int=Query(0,ge=0)):
 with connect() as c:
  total=c.execute("SELECT COUNT(*) FROM records").fetchone()[0]
  rows=c.execute("SELECT id,district,ac_number,assembly_name,part_no,part_name,blo_name,designation,mobile_number,updated_at FROM records ORDER BY district,assembly_name,part_no LIMIT ? OFFSET ?",(limit,offset)).fetchall()
 return {"version":1,"changed":since_version<1,"total":total,"items":[public(r) for r in rows]}
@app.post("/api/v1/admin/records")
def create_record(rec:RecordIn,x_admin_api_key:Optional[str]=Header(default=None)):
 guard(x_admin_api_key)
 with connect() as c:
  c.execute("INSERT INTO records VALUES(?,?,?,?,?,?,?,?,?,?)",(rec.id,rec.district,rec.ac_number,rec.assembly_name,rec.part_no,rec.part_name,rec.blo_name,rec.designation,rec.mobile_number,int(time.time())))
 return {"ok":True,"id":rec.id}
@app.put("/api/v1/admin/records/{record_id}")
def update_record(record_id:str,rec:RecordIn,x_admin_api_key:Optional[str]=Header(default=None)):
 guard(x_admin_api_key)
 if record_id!=rec.id:raise HTTPException(400,"Path id and body id must match.")
 with connect() as c:
  cur=c.execute("UPDATE records SET district=?,ac_number=?,assembly_name=?,part_no=?,part_name=?,blo_name=?,designation=?,mobile_number=?,updated_at=? WHERE id=?",(rec.district,rec.ac_number,rec.assembly_name,rec.part_no,rec.part_name,rec.blo_name,rec.designation,rec.mobile_number,int(time.time()),record_id))
  if cur.rowcount==0:raise HTTPException(404,"Record not found.")
 return {"ok":True,"id":record_id}
